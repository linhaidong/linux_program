# IP Operation in Python

- valid_ip_addr.py : validate IP address, ref:[how-to-validate-ip-address-in-python?](http://stackoverflow.com/questions/319279/how-to-validate-ip-address-in-python)

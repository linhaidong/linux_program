## Unix domain socket（unix域协议)客户端和服务端程序

使用说明：

服务端：
	
	python uds_server.py
	
客户端：

	python uds_client.py msg 
	如：
	python uds_client.py  12345678901234567890abcdefg
	


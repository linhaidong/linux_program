Python 整数和浮点数的数学运算

需要掌握的知识点：

- `decimal`模块
- `math`模块
- IEEE 754 标准
- Python浮点数的缺陷
